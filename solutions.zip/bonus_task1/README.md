1) Download and extract folder
2) pip3 install pandas
3) chmod u+x main_taskp.py (in directory where file is located)
4) python3 main_task.py