1) Download and extract folder
2) pip3 install pandas
3) pip3 install tkinter
4) chmod u+x main_taskp.py (in directory where file is located)
Works only in Python 3.5 and later versions
5) python3 main_task.py

Please use the examples and fill the areas using the same format as given because the program isn't protected from incorrect formats